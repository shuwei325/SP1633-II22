library(recipes)
library(tidyverse)
library(tidyquant)
library(timetk)
library(sweep)
library(forecast)
library(lubridate)

# 0. Ventas de bicicletas ----------------------------------------------------

?sweep::bike_sales
data<-sweep::bike_sales
str(data)
glimpse(data)

# 1. Ejemplo con 3 estados ------------------------------------------------

table(data$bikeshop.state)

#Seleccionar las variables de interés
data1 <- data %>% select(order.date, quantity, price, bikeshop.state)

#Seleccionar los 3 estados (CA,FL,NY)
data2 <- data1 %>% filter(bikeshop.state %in% c("CA","FL","NY"))
table(data2$bikeshop.state)

#equivalente a:
data2 <- data %>% select(order.date, quantity, price, bikeshop.state) %>%
                    filter(bikeshop.state %in% c("CA","FL","NY"))

# Crear nuevas variables
data3 <- data2 %>% mutate(month = month(order.date, label = TRUE),
                          total.price = quantity*price)
data3

# Resúmenes
data3 %>% group_by(bikeshop.state) %>%
          summarise(total.qty=sum(quantity))

data2_mensual <- data2 %>%
  mutate(month = month(order.date, label = FALSE), 
         year  = year(order.date)) %>%
  group_by(year, month) %>%
  summarise(total.qty = sum(quantity)) 

data2_mensual

data2_mensual %>%
  ggplot(aes(x = month, y = total.qty, group = year)) +
  geom_area(aes(fill = year), position = "stack") +
  labs(title = "Quantity Sold: Month Plot", x = "", y = "Sales",
       subtitle = "") +
  scale_y_continuous() +
  theme_tq()


# 2. Base completa --------------------------------------------------------
#Devolvemos a la base original

data1_mensual <- data1 %>%
  mutate(month = month(order.date, label = FALSE), 
         year  = year(order.date)) %>%
  group_by(year, month) %>%
  summarise(total.qty = sum(quantity)) 
data1_mensual

#Concanate two columns into one.
data1_mensual_time <- data1_mensual %>%  
                      unite(time, c("year", "month"), sep ="-")
data1_mensual_time

data1_mensual_time. <- data1_mensual_time %>%
                      separate(time, c("year", "month"), sep ="-")
data1_mensual_time.

data1_mensual
table(data1_mensual$year,data1_mensual$month)

venta <- ts(data1_mensual$total.qty, start = c(2011, 1), frequency = 12)

ts.plot(venta)

autoplot(venta) + labs(x ="t", y = "Quantity sold", title="") 

decompose.venta <- decompose(venta,"additive")
autoplot(decompose.venta)


# 3. Analizar series por FRAME ----------------------------------------------
# times series by frame

data4 <- data %>%
  mutate(month = month(order.date, label = FALSE), 
         year  = year(order.date)) %>%
  group_by(frame,year, month) %>%
  summarise(total.qty = sum(quantity)) %>%  
  unite(time, c("year", "month"), sep ="-")

date <- paste0(data4$time,"-",15)

data4$time2 <- as.Date(date, "%Y-%m-%d")

#Otra opción
data4 <- data %>%
  mutate(month = month(order.date, label = FALSE), 
         year  = year(order.date)) %>%
  group_by(frame,year, month) %>%
  summarise(total.qty = sum(quantity)) %>%
  mutate(time=make_date(year,month,1))



#Gráfico lineal

data4 %>%
  group_by(frame) %>%
  plot_time_series(time, total.qty, 
                   .facet_ncol = 2,                       #2 columnas
                   .facet_scales = "free",                #permite escalas diferentes en los gráficos
                   .interactive = TRUE)

#Gráfico de funciones de autocorrelación y autocorrelación parcial

data4 %>%
  group_by(frame) %>%
      plot_acf_diagnostics(.date_var = time2, 
                     .value = total.qty,               
                     .lags = 24, 
                     .interactive = FALSE)

# 4. Analizar series por categoría ----------------------------------------
# Otra alternativa --------------------------------------------------------

monthly_qty_by_cat2 <- bike_sales %>%
  mutate(order.month = as_date(as.yearmon(order.date))) %>%
  group_by(category.secondary, order.month) %>%
  summarise(total.qty = sum(quantity))

monthly_qty_by_cat2

# Modelar series por grupo ------------------------------------------------

#uso de nest() para crear grupos de series temporales.

monthly_qty_by_cat2_nest <- monthly_qty_by_cat2 %>%
  group_by(category.secondary) %>%
  nest()

monthly_qty_by_cat2_nest

glimpse(monthly_qty_by_cat2_nest)


# Paso 1: crear objetos de series temporales (mutate y map)
monthly_qty_by_cat2_ts <- monthly_qty_by_cat2_nest %>%
  mutate(data.ts = map(.x       = data, 
                       .f       = tk_ts, 
                       select   = -order.month, 
                       start    = 2011,
                       freq     = 12))

#verifique el objeto
class(monthly_qty_by_cat2_ts$data.ts[[1]])


# Paso 2: Modelación por grupo (suavizamiento exponencial: ets)

monthly_qty_by_cat2_fit <- monthly_qty_by_cat2_ts %>%
  mutate(fit.ets = map(data.ts, ets))

monthly_qty_by_cat2_fit

# Observar los parámetros estimados
monthly_qty_by_cat2_fit %>%
  mutate(tidy = map(fit.ets, sw_tidy)) %>%
  unnest(tidy) %>%
  spread(key = category.secondary, value = estimate)



# Observar las medidas de ajustes
monthly_qty_by_cat2_fit %>%
  mutate(glance = map(fit.ets, sw_glance)) %>%
  unnest(glance)


# Observar los residuales y los valores ajustados
augment_fit_ets <- monthly_qty_by_cat2_fit %>%
  mutate(augment = map(fit.ets, sw_augment, timetk_idx = TRUE, rename_index = "date")) %>%
  unnest(augment)

augment_fit_ets

augment_fit_ets %>%
  ggplot(aes(x = date, y = .actual, group = category.secondary)) +
  geom_line(color = "black") +
  geom_line(data = augment_fit_ets, 
            aes(x = date, y = .fitted, group = category.secondary),
            color = "red") +
  labs(title = "Bike Quantity Sold By Secondary Category",
       subtitle = "ETS Model Residuals", x = "") + 
  theme_tq() +
  facet_wrap(~ category.secondary, scale = "free_y", ncol = 3) +
  scale_x_date(date_labels = "%Y")



augment_fit_ets %>%
  ggplot(aes(x = date, y = .resid, group = category.secondary)) +
  geom_hline(yintercept = 0, color = "grey40") +
  geom_line(color = palette_light()[[2]]) +
  geom_smooth(method = "loess") +
  labs(title = "Bike Quantity Sold By Secondary Category",
       subtitle = "ETS Model Residuals", x = "") + 
  theme_tq() +
  facet_wrap(~ category.secondary, scale = "free_y", ncol = 3) +
  scale_x_date(date_labels = "%Y")



# Descomposición

monthly_qty_by_cat2_fit %>%
  mutate(decomp = map(fit.ets, sw_tidy_decomp, timetk_idx = TRUE, rename_index = "date")) %>%
  unnest(decomp)

 
# Pronóstico

monthly_qty_by_cat2_fcast <- monthly_qty_by_cat2_fit %>%
  mutate(fcast.ets = map(fit.ets, forecast, h = 12))
monthly_qty_by_cat2_fcast


monthly_qty_by_cat2_fcast_tidy <- monthly_qty_by_cat2_fcast %>%
  mutate(sweep = map(fcast.ets, sw_sweep, fitted = FALSE, timetk_idx = TRUE)) %>%
  unnest(sweep)
monthly_qty_by_cat2_fcast_tidy

monthly_qty_by_cat2_fcast_tidy %>%
  ggplot(aes(x = index, y = total.qty, color = key, group = category.secondary)) +
  geom_ribbon(aes(ymin = lo.95, ymax = hi.95), 
              fill = "#D5DBFF", color = NA, size = 0) +
  geom_ribbon(aes(ymin = lo.80, ymax = hi.80, fill = key), 
              fill = "#596DD5", color = NA, size = 0, alpha = 0.8) +
  geom_line() +
  labs(title = "Bike Quantity Sold By Secondary Category",
       subtitle = "ETS Model Forecasts",
       x = "", y = "Units") +
  scale_x_date(date_breaks = "1 year", date_labels = "%Y") +
  scale_color_tq() +
  scale_fill_tq() +
  facet_wrap(~ category.secondary, scales = "free_y", ncol = 3) +
  theme_tq() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

