
# Laboratorio 5 -----------------------------------------------------------


library(ggplot2)
library(forecast)
library(fpp2)

# 1. Ejemplo de ruido blanco ---------------------------------------------

w = rnorm(500,0,1) 
ts.plot(w)
acf(w,lag.max = 50,main="estimación de acf de w")


# 2. Ejemplo de medias móviles --------------------------------------------

w = rnorm(500,0,1) # 500 N(0,1) variates
v = stats::filter(w, sides=2, filter=rep(1/3,3)) # moving average
v = na.omit(v)
ts.plot(v)
acf(v,lag.max = 50,main="estimación de acf de v")

w = rnorm(500,0,1) # 500 N(0,1) variates
v = filter(w, sides=2, filter=rep(1/7,7)) # moving average
v = na.omit(v)
ts.plot(v)
acf(v,lag.max = 50,main="estimación de acf de v")

# 3. Ejemplo de sorteo navideño -------------------------------------------

sorteo<-read.csv("sorteo.csv",sep=",")
y<-ts(sorteo$numero)
autoplot(y)
ggAcf(y,lag.max = 50,main="estimación de acf")


# 4. Ejemplo de graduados de ITCR -----------------------------------------

itcrgrad<-read.csv("ITCR.csv",sep=",")
y<-ts(itcrgrad$graduados,start=1975)
autoplot(y) 
ggAcf(y)
w=diff(y)
autoplot(w) 
ggAcf(w)

# 5. Ejemplo de turistas -----------------------------------------

turistas<-read.csv("turistas.csv",sep=";")
y<-ts(turistas$turistas,start=c(1991,1),frequency=12)
autoplot(y) 
ggAcf(y)
w=diff(y)
autoplot(w) 
ggAcf(w)

autoplot(log(y)) 
ggAcf(log(y))
logw=diff(log(y))
autoplot(logw) 
ggAcf(logw)


